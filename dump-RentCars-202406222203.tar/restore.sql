--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "RentCars";
--
-- Name: RentCars; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "RentCars" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE "RentCars" OWNER TO postgres;

\connect "RentCars"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: rentalrequests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rentalrequests (
    id uuid NOT NULL,
    userid uuid NOT NULL,
    vehicleid uuid NOT NULL,
    rentalstartdatetimeutc timestamp without time zone NOT NULL,
    rentalenddatetimeutc timestamp without time zone NOT NULL,
    status integer NOT NULL,
    isremoved boolean NOT NULL,
    createddatetimeutc timestamp without time zone NOT NULL,
    modifieddatetimeutc timestamp without time zone
);


ALTER TABLE public.rentalrequests OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name character varying NOT NULL,
    tel character varying NOT NULL,
    login character varying NOT NULL,
    password character varying NOT NULL,
    avatarpath character varying,
    registrationdate timestamp without time zone NOT NULL,
    userrole integer NOT NULL,
    isremoved boolean NOT NULL,
    createddatetimeutc timestamp without time zone NOT NULL,
    modifieddatetimeutc timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: vehiclephotos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehiclephotos (
    id uuid NOT NULL,
    vehicleid uuid NOT NULL,
    path character varying NOT NULL
);


ALTER TABLE public.vehiclephotos OWNER TO postgres;

--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicles (
    id uuid NOT NULL,
    brand character varying NOT NULL,
    model character varying NOT NULL,
    vehicleclass integer NOT NULL,
    bodycolor character varying NOT NULL,
    bodytype integer NOT NULL,
    enginepower integer NOT NULL,
    enginecapacity double precision NOT NULL,
    fueltype integer NOT NULL,
    wheeldrive integer NOT NULL,
    daycost double precision NOT NULL,
    twofourdayscost double precision NOT NULL,
    foursevendayscost double precision NOT NULL,
    sevenfourteendayscost double precision NOT NULL,
    fourteenandmoredayscost double precision NOT NULL,
    isremoved boolean NOT NULL,
    createddatetimeutc timestamp without time zone NOT NULL,
    modifieddatetimeutc timestamp without time zone,
    yearofmanufacture integer NOT NULL,
    transmissiontype integer NOT NULL
);


ALTER TABLE public.vehicles OWNER TO postgres;

--
-- Data for Name: rentalrequests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rentalrequests (id, userid, vehicleid, rentalstartdatetimeutc, rentalenddatetimeutc, status, isremoved, createddatetimeutc, modifieddatetimeutc) FROM stdin;
\.
COPY public.rentalrequests (id, userid, vehicleid, rentalstartdatetimeutc, rentalenddatetimeutc, status, isremoved, createddatetimeutc, modifieddatetimeutc) FROM '$$PATH$$/4802.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, tel, login, password, avatarpath, registrationdate, userrole, isremoved, createddatetimeutc, modifieddatetimeutc) FROM stdin;
\.
COPY public.users (id, name, tel, login, password, avatarpath, registrationdate, userrole, isremoved, createddatetimeutc, modifieddatetimeutc) FROM '$$PATH$$/4800.dat';

--
-- Data for Name: vehiclephotos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehiclephotos (id, vehicleid, path) FROM stdin;
\.
COPY public.vehiclephotos (id, vehicleid, path) FROM '$$PATH$$/4803.dat';

--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicles (id, brand, model, vehicleclass, bodycolor, bodytype, enginepower, enginecapacity, fueltype, wheeldrive, daycost, twofourdayscost, foursevendayscost, sevenfourteendayscost, fourteenandmoredayscost, isremoved, createddatetimeutc, modifieddatetimeutc, yearofmanufacture, transmissiontype) FROM stdin;
\.
COPY public.vehicles (id, brand, model, vehicleclass, bodycolor, bodytype, enginepower, enginecapacity, fueltype, wheeldrive, daycost, twofourdayscost, foursevendayscost, sevenfourteendayscost, fourteenandmoredayscost, isremoved, createddatetimeutc, modifieddatetimeutc, yearofmanufacture, transmissiontype) FROM '$$PATH$$/4801.dat';

--
-- Name: rentalrequests rentalrequests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rentalrequests
    ADD CONSTRAINT rentalrequests_pkey PRIMARY KEY (id);


--
-- Name: users users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_key UNIQUE (login);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tel_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tel_key UNIQUE (tel);


--
-- Name: vehiclephotos vehiclephotos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehiclephotos
    ADD CONSTRAINT vehiclephotos_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

